
msg = "Hello World"
println(msg)

function f(x)
    3
end
